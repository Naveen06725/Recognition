package com.cs643.assignment1;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.rekognition.RekognitionClient;
import software.amazon.awssdk.services.rekognition.model.*;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.DeleteMessageRequest;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;
import java.util.ArrayList;

public class TextRecognitionApp {
    private static final String S3_BUCKET = "njit-cs-643";
    private static final String SQS_QUEUE_URL = "https://sqs.us-east-1.amazonaws.com/381491938896/car-detection-queue";
    private static final String OUTPUT_FILE = "output.txt";
    private static final Region REGION = Region.US_EAST_1;

    private final S3Client s3Client;
    private final RekognitionClient rekognitionClient;
    private final SqsClient sqsClient;

    public TextRecognitionApp() {
        // Initialize AWS clients
        this.s3Client = S3Client.builder().region(REGION).build();
        this.rekognitionClient = RekognitionClient.builder().region(REGION).build();
        this.sqsClient = SqsClient.builder().region(REGION).build();
    }

    public void processMessages() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(OUTPUT_FILE))) {
            boolean running = true;

            while (running) {
                // Receive messages from SQS
                ReceiveMessageRequest receiveRequest = ReceiveMessageRequest.builder()
                    .queueUrl(SQS_QUEUE_URL)
                    .maxNumberOfMessages(1)
                    .waitTimeSeconds(20)  // Long polling
                    .build();

                List<Message> messages = sqsClient.receiveMessage(receiveRequest).messages();

                for (Message message : messages) {
                    String imageKey = message.body();

                    // Check for termination signal
                    if (imageKey.equals("-1")) {
                        running = false;
                        break;
                    }

                    // Process the image
                    processImage(imageKey, writer);

                    // Delete the processed message
                    DeleteMessageRequest deleteRequest = DeleteMessageRequest.builder()
                        .queueUrl(SQS_QUEUE_URL)
                        .receiptHandle(message.receiptHandle())
                        .build();
                    sqsClient.deleteMessage(deleteRequest);
                }
            }

        } catch (Exception e) {
            System.err.println("Error processing messages: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Close AWS clients
            s3Client.close();
            rekognitionClient.close();
            sqsClient.close();
        }
    }

    private void processImage(String imageKey, PrintWriter writer) {
        try {
            // Create text detection request
            Image image = Image.builder()
                .s3Object(S3Object.builder()
                    .bucket(S3_BUCKET)
                    .name(imageKey)
                    .build())
                .build();

            DetectTextRequest request = DetectTextRequest.builder()
                .image(image)
                .build();

            // Detect text in the image
            DetectTextResponse response = rekognitionClient.detectText(request);
            List<TextDetection> textDetections = response.textDetections();

            // Write results to file
            if (!textDetections.isEmpty()) {
                writer.println("Image: " + imageKey);
                writer.println("Detected Text:");
                for (TextDetection text : textDetections) {
                    if (text.type() == TextTypes.WORD) {
                        writer.println("- " + text.detectedText() + " (Confidence: " + text.confidence() + "%)");
                    }
                }
                writer.println();
                writer.flush();
            }

        } catch (Exception e) {
            System.err.println("Error processing image " + imageKey + ": " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        TextRecognitionApp app = new TextRecognitionApp();
        app.processMessages();
    }
}
