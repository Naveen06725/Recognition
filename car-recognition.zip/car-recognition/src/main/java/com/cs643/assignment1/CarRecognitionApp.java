package com.cs643.assignment1;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.rekognition.RekognitionClient;
import software.amazon.awssdk.services.rekognition.model.*;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import java.util.List;

public class CarRecognitionApp {
    private static final String S3_BUCKET = "njit-cs-643";
    private static final String SQS_QUEUE_URL = "https://sqs.us-east-1.amazonaws.com/381491938896/car-detection-queue";
    private static final float CONFIDENCE_THRESHOLD = 90.0f;
    private static final Region REGION = Region.US_EAST_1;

    private final S3Client s3Client;
    private final RekognitionClient rekognitionClient;
    private final SqsClient sqsClient;

    public CarRecognitionApp() {
        // Initialize AWS clients
        this.s3Client = S3Client.builder().region(REGION).build();
        this.rekognitionClient = RekognitionClient.builder().region(REGION).build();
        this.sqsClient = SqsClient.builder().region(REGION).build();
    }

    public void processImages() {
        try {
            // Process 10 images from S3 bucket
            for (int i = 1; i <= 10; i++) {
                String imageKey = i + ".jpg";
                if (processImage(imageKey)) {
                    System.out.println("Car detected in image: " + imageKey);
                    sendMessageToSQS(imageKey);
                }
            }

            // Send termination signal
            sendMessageToSQS("-1");
            System.out.println("Processing completed. Termination signal sent.");

        } catch (Exception e) {
            System.err.println("Error processing images: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Close AWS clients
            s3Client.close();
            rekognitionClient.close();
            sqsClient.close();
        }
    }

    private boolean processImage(String imageKey) {
        try {
            // Create image detection request
            Image image = Image.builder()
                .s3Object(S3Object.builder()
                    .bucket(S3_BUCKET)
                    .name(imageKey)
                    .build())
                .build();

            DetectLabelsRequest request = DetectLabelsRequest.builder()
                .image(image)
                .minConfidence(CONFIDENCE_THRESHOLD)
                .build();

            // Detect labels in the image
            DetectLabelsResponse response = rekognitionClient.detectLabels(request);

            // Check if any label indicates a car with confidence > 90%
            return response.labels().stream()
                .anyMatch(label -> 
                    (label.name().toLowerCase().equals("car") ||
                     label.name().toLowerCase().equals("automobile") ||
                     label.name().toLowerCase().equals("vehicle")) &&
                    label.confidence() >= CONFIDENCE_THRESHOLD
                );

        } catch (Exception e) {
            System.err.println("Error processing image " + imageKey + ": " + e.getMessage());
            return false;
        }
    }

    private void sendMessageToSQS(String message) {
        try {
            SendMessageRequest sendMessageRequest = SendMessageRequest.builder()
                .queueUrl(SQS_QUEUE_URL)
                .messageBody(message)
                .build();
            sqsClient.sendMessage(sendMessageRequest);
        } catch (Exception e) {
            System.err.println("Error sending message to SQS: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        CarRecognitionApp app = new CarRecognitionApp();
        app.processImages();
    }
}
